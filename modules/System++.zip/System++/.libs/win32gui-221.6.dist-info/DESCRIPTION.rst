
Python extensions for Microsoft Windows'
Provides access to much of the Win32 API, the
ability to create and use COM objects, and the
Pythonwin environment

This provides the MFC classes. 


