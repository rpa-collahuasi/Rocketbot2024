from win32 import ras as _
from win32._kras import *