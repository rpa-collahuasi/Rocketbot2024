from win32._internet import *
